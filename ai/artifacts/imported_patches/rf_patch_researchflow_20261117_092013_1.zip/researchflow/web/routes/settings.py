"""Settings panel for project method context and read-only configuration."""

from __future__ import annotations

from pathlib import Path
from urllib.parse import quote

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from researchflow.project.method_context import (
    CHARTER_PATH, PROTOCOL_PATH, RENDERING_PATH,
    ProtocolAlreadyInstalledError, install_protocol,
)
from researchflow.web.routes.dashboard import _resolve_project

router = APIRouter()


def _root(request: Request, slug: str) -> Path:
    """Resolve a project using the same lookup as the dashboard."""
    config, root = _resolve_project(request, slug, request.app.state.machine)
    if config is None or root is None:
        raise HTTPException(status_code=404, detail="Project not open")
    return root


@router.get("/project/{slug}/settings", response_class=HTMLResponse)
async def settings_page(request: Request, slug: str, msg: str = "") -> HTMLResponse:
    """Show fixed method documents and the read-only project TOML."""
    root = _root(request, slug)
    rendering = root / RENDERING_PATH
    text = rendering.read_text(encoding="utf-8") if rendering.is_file() else None
    toml_path = root / ".researchflow/project.toml"
    toml_text = toml_path.read_text(encoding="utf-8") if toml_path.is_file() else ""

    # Links lead to the ordinary Files surface; Settings does not edit them.
    paths = (PROTOCOL_PATH, CHARTER_PATH, RENDERING_PATH)
    links = {p.name: "/project/" + quote(slug, safe="") + "/files?path=" + quote(p.as_posix(), safe="") for p in paths}
    return request.app.state.templates.TemplateResponse(
        request=request, name="settings.html", context={
            "slug": slug, "active_panel": "settings", "msg": msg,
            "protocol_present": (root / PROTOCOL_PATH).is_file(),
            "charter_present": (root / CHARTER_PATH).is_file(),
            "rendering_text": text, "rendering_length": len(text) if text is not None else 0,
            "toml_text": toml_text, "links": links,
        },
    )


@router.post("/project/{slug}/settings/install-protocol")
async def settings_install_protocol(request: Request, slug: str) -> RedirectResponse:
    """Install the reference protocol once, without implicit replacement."""
    root = _root(request, slug)
    try:
        install_protocol(root)
        msg = "installed"
    except ProtocolAlreadyInstalledError:
        msg = "already-present"
    return RedirectResponse(f"/project/{quote(slug, safe='')}/settings?msg={msg}", status_code=303)
