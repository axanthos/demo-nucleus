"""Settings panel presentation and method-context route tests."""

from __future__ import annotations

from pathlib import Path

from fastapi.testclient import TestClient

from researchflow.config.machine_models import (
    MachineAppConfig,
    MachineConfig,
    MachineEditorConfig,
    MachinePathsConfig,
    MachineRecentProjectsConfig,
)
from researchflow.web.app import create_app


def _project(root: Path, name: str = "settings-proj") -> Path:
    """Create the smallest project accepted by the normal project loader."""
    project_root = root / name
    rf_dir = project_root / ".researchflow"
    rf_dir.mkdir(parents=True)
    (rf_dir / "project.toml").write_text(
        f'[project]\nname = "{name}"\ndescription = ""\n'
        'created = "2026-11-17"\ntemplate = "minimal-package"\n'
        'schema_version = 1\n\n[git]\nplatform = "github"\n'
        'remote = ""\nvisibility = "private"\n\n[layout]\n'
        'packages = "src"\ntests = "tests"\nspecs = "specs"\n'
        'writeups = "writeups"\noutput = ""\ndata = "data"\n'
        'scripts = "scripts"\nai = "ai"\nreferences = "references"\n\n'
        '[overleaf]\nenabled = false\n\n[zotero]\nenabled = false\n\n'
        '[ai]\ndefault_provider = "anthropic-sonnet"\n\n'
        '[editor]\ngit_client = "github"\n',
        encoding="utf-8",
    )
    return project_root


def _client(tmp_path: Path, project_root: Path) -> TestClient:
    """Create an app that can recover the project through recent projects."""
    machine = MachineConfig(
        app=MachineAppConfig(port=7842),
        paths=MachinePathsConfig(
            projects_root=str(tmp_path),
            patch_inbox=str(tmp_path / "inbox"),
        ),
        editor=MachineEditorConfig(git_client=""),
        recent_projects=MachineRecentProjectsConfig(paths=(str(project_root),)),
    )
    return TestClient(create_app(machine), follow_redirects=False)


def test_settings_uses_rf_panel_structure_and_controls(tmp_path: Path) -> None:
    """Settings follows RF card/button conventions instead of raw HTML controls."""
    project_root = _project(tmp_path)
    client = _client(tmp_path, project_root)

    response = client.get("/project/settings-proj/settings")

    assert response.status_code == 200
    assert '/static/settings.css?v=' in response.text
    assert 'class="settings-panel"' in response.text
    assert 'class="settings-section"' in response.text
    assert 'class="settings-item"' in response.text
    assert 'class="btn btn-primary btn-sm"' in response.text
    assert "Copy project.toml" not in response.text


def test_settings_collapses_long_rendering_and_project_toml(tmp_path: Path) -> None:
    """Long read-only content is available without dominating the default page."""
    project_root = _project(tmp_path)
    rendering = project_root / "ai/context/renderings/webui_project_instructions.md"
    rendering.parent.mkdir(parents=True)
    rendering.write_text("Rendered instructions\nSecond line\n", encoding="utf-8")

    client = _client(tmp_path, project_root)
    response = client.get("/project/settings-proj/settings")

    assert response.status_code == 200
    assert 'id="rf-rendering-copy-source"' in response.text
    assert 'onclick="rfSettingsCopy(' in response.text
    assert "Copy instructions" in response.text
    assert ">Ready<" not in response.text
    assert 'class="settings-disclosure"' in response.text
    assert "Preview instructions" in response.text
    assert "View raw project.toml" in response.text
    assert "<textarea" not in response.text

def test_settings_document_actions_deep_link_to_selected_file(tmp_path: Path) -> None:
    """Method-document Files actions preload the exact target file."""
    project_root = _project(tmp_path)
    documents = (
        "ai/context/rf_method_protocol.md",
        "ai/context/project_charter.md",
        "ai/context/renderings/webui_project_instructions.md",
    )
    for rel_path in documents:
        target = project_root / rel_path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(f"{rel_path}\n", encoding="utf-8")

    client = _client(tmp_path, project_root)
    response = client.get("/project/settings-proj/settings")

    assert response.status_code == 200
    assert '/project/settings-proj/files?path=ai%2Fcontext%2Frf_method_protocol.md' in response.text
    assert '/project/settings-proj/files?path=ai%2Fcontext%2Fproject_charter.md' in response.text
    assert '/project/settings-proj/files?path=ai%2Fcontext%2Frenderings%2Fwebui_project_instructions.md' in response.text

