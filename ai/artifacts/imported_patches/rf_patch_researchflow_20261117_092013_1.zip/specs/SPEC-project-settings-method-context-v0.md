# SPEC — Project settings: method context v0

Status: implementation candidate (2026-11-17)

## Scope and authority

Settings is a navigation/configuration surface, not a second governed editor.
For an existing project, install a byte-for-byte autonomous copy of the RF
method protocol distributed with the RF application. Installation is explicit,
non-destructive, and does not generate a charter or WebUI instructions.
The installed protocol is an ordinary project file and is never silently updated.

The installed protocol (`ai/context/rf_method_protocol.md`), project charter
(`ai/context/project_charter.md`) and WebUI rendering
(`ai/context/renderings/webui_project_instructions.md`) deep-link to their exact
file view in Files when present; the user must not have to relocate the document
from the Files root. Editing, review and ratification remain in the existing governed
workflow. The rendering is copied verbatim with its UTF-8 character count;
no freshness claim is made without provenance evidence. The 6,000-character
WebUI target is advisory and displayed; copying remains possible above it.

Settings also makes `.researchflow/project.toml` inspectable on clients where
hidden RF files are otherwise inaccessible. It is configuration evidence, not a
paste-oriented artifact: the raw TOML is read-only, collapsed by default, and
has no copy or edit control in v0.

## Information architecture and visual conventions

The panel must reuse RF's established interface language rather than render a
stack of document headings and native browser controls.

- Page title: use the standard RF panel title treatment and Settings icon.
- Method context: one bordered section card containing three document rows
  (protocol, charter, WebUI instructions), separated by subtle dividers.
- Each row gives the document name primary emphasis, concise status/metadata
  secondary emphasis, and right-aligned RF button controls for available actions.
- `Open in Files` is a secondary action; protocol installation is the primary
  action only while the protocol is absent.
- WebUI text is not expanded by default. Copy is available without preview;
  an optional disclosure reveals a read-only pre-wrapped preview.
- Project configuration is a separate bordered section card. `project.toml`
  is represented as one read-only configuration item with a collapsed raw-file
  disclosure. No copy control is shown.
- Long content must not dominate the default mobile page. Controls must use RF
  button classes and mobile wrapping/touch conventions, not browser-native button
  styling.

## Failure and security

Project resolution uses the existing project registry/recovery helper.
Installation never overwrites an existing protocol (including empty files),
never modifies the RF source template, and registers the new file as a project
artifact. A missing bundled template is a visible error, not a fabricated
replacement. Only fixed paths are exposed. POST uses the existing application
security boundary. No network or model calls.

## Acceptance

- Fresh project: protocol absent, explicit install creates exact bundled bytes.
- Repeat install: no overwrite; existing bytes unchanged.
- Charter/rendering absent: no synthetic files or false readiness claims.
- Rendering present: text is copied exactly, count is correct, and preview is
  collapsed by default.
- TOML is inspectable read-only in a collapsed disclosure, with no copy/edit UI.
- Settings uses RF-styled cards, buttons, hierarchy, and mobile-responsive layout.
- Each available method-document Files action opens that exact file directly.
- Existing Files and other panels remain unchanged.
