+++
schema = "rf-episode-manifest/v0-draft"
project = "researchflow"
lane = "chat"
client = "chatgpt"
model = "gpt-5.6-sol"
date = "2026-11-17"
episode = "settings-file-deep-links"
patches = ["rf_patch_researchflow_20261117_092013.zip"]
+++

## Intention
Make each Settings method-document action open the exact document in Files instead of landing at the Files root and forcing the user to relocate it.

## Decisions
Reuse the existing Files `path` query contract rather than add a new route or selection mechanism. Apply the same deep-link behavior to the installed RF method protocol, project charter, and WebUI project instructions. Keep Files as the editing/governance surface and Settings as navigation/configuration.

## Artifacts
- `specs/SPEC-project-settings-method-context-v0.md`
- `researchflow/web/routes/settings.py`
- `tests/web/test_settings.py`

## Sources
- Researcher mobile smoke-test feedback from the Settings method-context implementation.
- `researchflow/web/routes/files.py`
- `researchflow/web/routes/patch.py`

## Relations
- `researchflow/web/routes/settings.py -> implements -> specs/SPEC-project-settings-method-context-v0.md`
- `tests/web/test_settings.py -> tests -> researchflow/web/routes/settings.py`
- `researchflow/web/routes/settings.py -> depends_on -> researchflow/web/routes/files.py`

## Open points
The deep links are covered by the Settings regression test and rely on the already-tested Files `path` contract. Researcher mobile smoke validation remains useful after application.
